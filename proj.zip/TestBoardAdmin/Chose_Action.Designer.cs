﻿namespace TestBoardAdmin
{
    partial class Chose_Action
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.button_chose_option_add_quiz = new System.Windows.Forms.Button();
            this.button_chose_action_view_results = new System.Windows.Forms.Button();
            this.button_chose_action_view_added_quizes = new System.Windows.Forms.Button();
            this.user_lbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Monotype Corsiva", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Maroon;
            this.label1.Location = new System.Drawing.Point(47, 11);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(891, 72);
            this.label1.TabIndex = 2;
            this.label1.Text = "WELCOME TO TEAHERS PORTAL";
            // 
            // button_chose_option_add_quiz
            // 
            this.button_chose_option_add_quiz.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button_chose_option_add_quiz.Font = new System.Drawing.Font("Monotype Corsiva", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_chose_option_add_quiz.Location = new System.Drawing.Point(409, 129);
            this.button_chose_option_add_quiz.Margin = new System.Windows.Forms.Padding(4);
            this.button_chose_option_add_quiz.Name = "button_chose_option_add_quiz";
            this.button_chose_option_add_quiz.Size = new System.Drawing.Size(205, 85);
            this.button_chose_option_add_quiz.TabIndex = 3;
            this.button_chose_option_add_quiz.Text = "ADD QUIZ";
            this.button_chose_option_add_quiz.UseVisualStyleBackColor = false;
            this.button_chose_option_add_quiz.Click += new System.EventHandler(this.button_chose_option_add_quiz_Click);
            // 
            // button_chose_action_view_results
            // 
            this.button_chose_action_view_results.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button_chose_action_view_results.Font = new System.Drawing.Font("Monotype Corsiva", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_chose_action_view_results.Location = new System.Drawing.Point(409, 363);
            this.button_chose_action_view_results.Margin = new System.Windows.Forms.Padding(4);
            this.button_chose_action_view_results.Name = "button_chose_action_view_results";
            this.button_chose_action_view_results.Size = new System.Drawing.Size(205, 85);
            this.button_chose_action_view_results.TabIndex = 4;
            this.button_chose_action_view_results.Text = "VIEW RESULTS";
            this.button_chose_action_view_results.UseVisualStyleBackColor = false;
            this.button_chose_action_view_results.Click += new System.EventHandler(this.button_chose_action_view_results_Click);
            // 
            // button_chose_action_view_added_quizes
            // 
            this.button_chose_action_view_added_quizes.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button_chose_action_view_added_quizes.Font = new System.Drawing.Font("Monotype Corsiva", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_chose_action_view_added_quizes.Location = new System.Drawing.Point(409, 245);
            this.button_chose_action_view_added_quizes.Margin = new System.Windows.Forms.Padding(4);
            this.button_chose_action_view_added_quizes.Name = "button_chose_action_view_added_quizes";
            this.button_chose_action_view_added_quizes.Size = new System.Drawing.Size(205, 85);
            this.button_chose_action_view_added_quizes.TabIndex = 5;
            this.button_chose_action_view_added_quizes.Text = "VIEW ADDED QUIZES";
            this.button_chose_action_view_added_quizes.UseVisualStyleBackColor = false;
            this.button_chose_action_view_added_quizes.Click += new System.EventHandler(this.button_chose_action_view_added_quizes_Click);
            // 
            // user_lbl
            // 
            this.user_lbl.AutoSize = true;
            this.user_lbl.Location = new System.Drawing.Point(482, 94);
            this.user_lbl.Name = "user_lbl";
            this.user_lbl.Size = new System.Drawing.Size(0, 17);
            this.user_lbl.TabIndex = 6;
            // 
            // Chose_Action
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.user_lbl);
            this.Controls.Add(this.button_chose_action_view_added_quizes);
            this.Controls.Add(this.button_chose_action_view_results);
            this.Controls.Add(this.button_chose_option_add_quiz);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Chose_Action";
            this.Text = "Chose_Action";
            this.Load += new System.EventHandler(this.Chose_Action_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button_chose_option_add_quiz;
        private System.Windows.Forms.Button button_chose_action_view_results;
        private System.Windows.Forms.Button button_chose_action_view_added_quizes;
        private System.Windows.Forms.Label user_lbl;
    }
}