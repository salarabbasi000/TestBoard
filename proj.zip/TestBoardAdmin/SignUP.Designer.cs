﻿namespace TestBoardAdmin
{
    partial class SignUP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.radioButton_Signup_Female = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.radioButton_Signup_Male = new System.Windows.Forms.RadioButton();
            this.textBox_SignUp_Name = new System.Windows.Forms.TextBox();
            this.textBox_Signup_Email = new System.Windows.Forms.TextBox();
            this.textBox_SignUp_Pass = new System.Windows.Forms.TextBox();
            this.textBox_Signup_ConPass = new System.Windows.Forms.TextBox();
            this.button_SignUP = new System.Windows.Forms.Button();
            this.link_login = new System.Windows.Forms.LinkLabel();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Lucida Handwriting", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(25, 146);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(121, 36);
            this.label2.TabIndex = 1;
            this.label2.Text = "Name :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Lucida Handwriting", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(25, 218);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(123, 36);
            this.label3.TabIndex = 2;
            this.label3.Text = "Email :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Lucida Handwriting", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(25, 284);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(174, 36);
            this.label4.TabIndex = 3;
            this.label4.Text = "Password :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Lucida Handwriting", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(25, 358);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(308, 36);
            this.label5.TabIndex = 4;
            this.label5.Text = "Confirm Password :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Lucida Handwriting", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(25, 420);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(142, 36);
            this.label7.TabIndex = 6;
            this.label7.Text = "Gender :";
            // 
            // radioButton_Signup_Female
            // 
            this.radioButton_Signup_Female.AutoSize = true;
            this.radioButton_Signup_Female.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton_Signup_Female.ForeColor = System.Drawing.Color.Black;
            this.radioButton_Signup_Female.Location = new System.Drawing.Point(540, 423);
            this.radioButton_Signup_Female.Margin = new System.Windows.Forms.Padding(4);
            this.radioButton_Signup_Female.Name = "radioButton_Signup_Female";
            this.radioButton_Signup_Female.Size = new System.Drawing.Size(95, 28);
            this.radioButton_Signup_Female.TabIndex = 8;
            this.radioButton_Signup_Female.TabStop = true;
            this.radioButton_Signup_Female.Text = "Female";
            this.radioButton_Signup_Female.UseVisualStyleBackColor = true;
            this.radioButton_Signup_Female.CheckedChanged += new System.EventHandler(this.radioButton_Signup_Female_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Monotype Corsiva", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(381, 11);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(256, 72);
            this.label1.TabIndex = 9;
            this.label1.Text = "SIGN UP";
            // 
            // radioButton_Signup_Male
            // 
            this.radioButton_Signup_Male.AutoSize = true;
            this.radioButton_Signup_Male.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton_Signup_Male.ForeColor = System.Drawing.Color.Black;
            this.radioButton_Signup_Male.Location = new System.Drawing.Point(369, 423);
            this.radioButton_Signup_Male.Margin = new System.Windows.Forms.Padding(4);
            this.radioButton_Signup_Male.Name = "radioButton_Signup_Male";
            this.radioButton_Signup_Male.Size = new System.Drawing.Size(72, 28);
            this.radioButton_Signup_Male.TabIndex = 10;
            this.radioButton_Signup_Male.TabStop = true;
            this.radioButton_Signup_Male.Text = "Male";
            this.radioButton_Signup_Male.UseVisualStyleBackColor = true;
            this.radioButton_Signup_Male.CheckedChanged += new System.EventHandler(this.radioButton_Signup_Male_CheckedChanged);
            // 
            // textBox_SignUp_Name
            // 
            this.textBox_SignUp_Name.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.textBox_SignUp_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SignUp_Name.Location = new System.Drawing.Point(369, 144);
            this.textBox_SignUp_Name.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_SignUp_Name.Name = "textBox_SignUp_Name";
            this.textBox_SignUp_Name.Size = new System.Drawing.Size(560, 34);
            this.textBox_SignUp_Name.TabIndex = 11;
            this.textBox_SignUp_Name.TextChanged += new System.EventHandler(this.textBox_SignUp_Name_TextChanged);
            // 
            // textBox_Signup_Email
            // 
            this.textBox_Signup_Email.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.textBox_Signup_Email.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_Signup_Email.Location = new System.Drawing.Point(369, 215);
            this.textBox_Signup_Email.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_Signup_Email.Name = "textBox_Signup_Email";
            this.textBox_Signup_Email.Size = new System.Drawing.Size(560, 34);
            this.textBox_Signup_Email.TabIndex = 12;
            this.textBox_Signup_Email.TextChanged += new System.EventHandler(this.textBox_Signup_Email_TextChanged);
            // 
            // textBox_SignUp_Pass
            // 
            this.textBox_SignUp_Pass.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.textBox_SignUp_Pass.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SignUp_Pass.Location = new System.Drawing.Point(369, 279);
            this.textBox_SignUp_Pass.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_SignUp_Pass.Name = "textBox_SignUp_Pass";
            this.textBox_SignUp_Pass.PasswordChar = '*';
            this.textBox_SignUp_Pass.Size = new System.Drawing.Size(560, 37);
            this.textBox_SignUp_Pass.TabIndex = 13;
            // 
            // textBox_Signup_ConPass
            // 
            this.textBox_Signup_ConPass.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.textBox_Signup_ConPass.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_Signup_ConPass.Location = new System.Drawing.Point(369, 354);
            this.textBox_Signup_ConPass.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_Signup_ConPass.Name = "textBox_Signup_ConPass";
            this.textBox_Signup_ConPass.PasswordChar = '*';
            this.textBox_Signup_ConPass.Size = new System.Drawing.Size(560, 37);
            this.textBox_Signup_ConPass.TabIndex = 14;
            this.textBox_Signup_ConPass.TextChanged += new System.EventHandler(this.textBox_Signup_ConPass_TextChanged);
            // 
            // button_SignUP
            // 
            this.button_SignUP.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button_SignUP.Font = new System.Drawing.Font("Lucida Handwriting", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_SignUP.ForeColor = System.Drawing.Color.Black;
            this.button_SignUP.Location = new System.Drawing.Point(817, 489);
            this.button_SignUP.Margin = new System.Windows.Forms.Padding(4);
            this.button_SignUP.Name = "button_SignUP";
            this.button_SignUP.Size = new System.Drawing.Size(199, 50);
            this.button_SignUP.TabIndex = 15;
            this.button_SignUP.Text = "SIGN UP";
            this.button_SignUP.UseVisualStyleBackColor = false;
            this.button_SignUP.Click += new System.EventHandler(this.button_SignUP_Click);
            // 
            // link_login
            // 
            this.link_login.AutoSize = true;
            this.link_login.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.link_login.Location = new System.Drawing.Point(340, 500);
            this.link_login.Name = "link_login";
            this.link_login.Size = new System.Drawing.Size(398, 25);
            this.link_login.TabIndex = 16;
            this.link_login.TabStop = true;
            this.link_login.Text = "Already Have an account? Sign In Here.";
            this.link_login.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.link_login_LinkClicked);
            // 
            // SignUP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.link_login);
            this.Controls.Add(this.button_SignUP);
            this.Controls.Add(this.textBox_Signup_ConPass);
            this.Controls.Add(this.textBox_SignUp_Pass);
            this.Controls.Add(this.textBox_Signup_Email);
            this.Controls.Add(this.textBox_SignUp_Name);
            this.Controls.Add(this.radioButton_Signup_Male);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.radioButton_Signup_Female);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.ForeColor = System.Drawing.Color.Maroon;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "SignUP";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.SignUP_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.RadioButton radioButton_Signup_Female;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton radioButton_Signup_Male;
        private System.Windows.Forms.TextBox textBox_SignUp_Name;
        private System.Windows.Forms.TextBox textBox_Signup_Email;
        private System.Windows.Forms.TextBox textBox_SignUp_Pass;
        private System.Windows.Forms.TextBox textBox_Signup_ConPass;
        private System.Windows.Forms.Button button_SignUP;
        private System.Windows.Forms.LinkLabel link_login;
    }
}

