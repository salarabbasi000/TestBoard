﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestBoardAdmin
{
    public partial class Add_Quiz : Form
    {
        public Add_Quiz()
        {
            InitializeComponent();
        }

        private void textBox_Add_Quiz_Quiz_Name_TextChanged(object sender, EventArgs e)
        {

        }


        private void textBox_Add_Quiz_QuizTime_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // this.Hide();

            ServiceReference.Service1Client client = new ServiceReference.Service1Client();

            var teach_id = session.Instance.user.t_id;
            Quiz q = new Quiz();
            q.quiz_name = textBox_Add_Quiz_Quiz_Name.Text;
            q.quiz_code = text_quiz_code_display.Text;
            q.time = dateTimePicker1.Value.TimeOfDay;
            q.teacher_id = teach_id;

            Tuple<string,string,TimeSpan,int> x=client.AddQuiz(teach_id, q.quiz_name,q.quiz_code,(TimeSpan)q.time);
            session.Instance.quiz.quiz_name = x.Item1;
            session.Instance.quiz.quiz_code = x.Item2;
            session.Instance.quiz.time = x.Item3;
            session.Instance.quiz.teacher_id = x.Item4;

            /*using (ExamModels obj = new ExamModels())
            {
                var teach_id = session.Instance.user.t_id;
                Quiz q = new Quiz()
                {
                    quiz_name = textBox_Add_Quiz_Quiz_Name.Text,
                    quiz_code = text_quiz_code_display.Text,
                    time = dateTimePicker1.Value.TimeOfDay,
                    teacher_id = teach_id,
                    
                };

                session.Instance.quiz = q;
                obj.Quizs.Add(q);
                obj.SaveChanges();

            }
            */
            MCQ mcq = new MCQ();
            mcq.Show();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            dateTimePicker1.CustomFormat = "HH:mm:ss";
        }
        string pass;
        private void code_btn_Click(object sender, EventArgs e)
        {
            //RandomGenerator generator = new RandomGenerator();
            pass = RandomPassword();
            text_quiz_code_display.Text = (pass).ToString();
            //MCQ.get_code(pass);


        }

        public string RandomPassword()
        {
            StringBuilder builder = new StringBuilder();
            builder.Append(RandomString(4, true));
            builder.Append(RandomNumber(1000, 9999));
            builder.Append(RandomString(2, false));
            return builder.ToString();
        }

        public int RandomNumber(int min, int max)
        {
            Random random = new Random();
            return random.Next(min, max);
        }

        // Generate a random string with a given size    
        public string RandomString(int size, bool lowerCase)
        {
            StringBuilder builder = new StringBuilder();
            Random random = new Random();
            char ch;
            for (int i = 0; i < size; i++)
            {
                ch = Convert.ToChar(Convert.ToInt32(Math.Floor(26 * random.NextDouble() + 65)));
                builder.Append(ch);
            }
            if (lowerCase)
                return builder.ToString().ToLower();
            return builder.ToString();
        }

        private void text_quiz_code_display_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
