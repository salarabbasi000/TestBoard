﻿namespace TestBoardAdmin
{
    partial class Blanks
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_blanks_Question = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button_Blanks_ADD = new System.Windows.Forms.Button();
            this.button_Blanks_Finish = new System.Windows.Forms.Button();
            this.textBox_blanks_CorrectAnswer = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Monotype Corsiva", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Maroon;
            this.label1.Location = new System.Drawing.Point(232, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(319, 57);
            this.label1.TabIndex = 2;
            this.label1.Text = "ADD BLANKS";
            // 
            // textBox_blanks_Question
            // 
            this.textBox_blanks_Question.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.textBox_blanks_Question.Location = new System.Drawing.Point(242, 101);
            this.textBox_blanks_Question.Multiline = true;
            this.textBox_blanks_Question.Name = "textBox_blanks_Question";
            this.textBox_blanks_Question.Size = new System.Drawing.Size(508, 92);
            this.textBox_blanks_Question.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Lucida Handwriting", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(47, 124);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 21);
            this.label2.TabIndex = 5;
            this.label2.Text = "Question :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(239, 205);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(240, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "(Type _______ where you want to add the blank)";
            // 
            // button_Blanks_ADD
            // 
            this.button_Blanks_ADD.Font = new System.Drawing.Font("Lucida Handwriting", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Blanks_ADD.Location = new System.Drawing.Point(567, 407);
            this.button_Blanks_ADD.Name = "button_Blanks_ADD";
            this.button_Blanks_ADD.Size = new System.Drawing.Size(75, 31);
            this.button_Blanks_ADD.TabIndex = 18;
            this.button_Blanks_ADD.Text = "ADD";
            this.button_Blanks_ADD.UseVisualStyleBackColor = true;
            this.button_Blanks_ADD.Click += new System.EventHandler(this.button_Blanks_ADD_Click);
            // 
            // button_Blanks_Finish
            // 
            this.button_Blanks_Finish.Font = new System.Drawing.Font("Lucida Handwriting", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Blanks_Finish.Location = new System.Drawing.Point(691, 407);
            this.button_Blanks_Finish.Name = "button_Blanks_Finish";
            this.button_Blanks_Finish.Size = new System.Drawing.Size(98, 31);
            this.button_Blanks_Finish.TabIndex = 17;
            this.button_Blanks_Finish.Text = "FINISH";
            this.button_Blanks_Finish.UseVisualStyleBackColor = true;
            this.button_Blanks_Finish.Click += new System.EventHandler(this.button_Blanks_Finish_Click);
            // 
            // textBox_blanks_CorrectAnswer
            // 
            this.textBox_blanks_CorrectAnswer.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.textBox_blanks_CorrectAnswer.Location = new System.Drawing.Point(242, 258);
            this.textBox_blanks_CorrectAnswer.Name = "textBox_blanks_CorrectAnswer";
            this.textBox_blanks_CorrectAnswer.Size = new System.Drawing.Size(280, 20);
            this.textBox_blanks_CorrectAnswer.TabIndex = 15;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Lucida Handwriting", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(25, 258);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(153, 21);
            this.label7.TabIndex = 14;
            this.label7.Text = "Correct Answer :";
            // 
            // Blanks
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button_Blanks_ADD);
            this.Controls.Add(this.button_Blanks_Finish);
            this.Controls.Add(this.textBox_blanks_CorrectAnswer);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBox_blanks_Question);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Blanks";
            this.Text = "Blanks";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox_blanks_Question;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button_Blanks_ADD;
        private System.Windows.Forms.Button button_Blanks_Finish;
        private System.Windows.Forms.TextBox textBox_blanks_CorrectAnswer;
        private System.Windows.Forms.Label label7;
    }
}