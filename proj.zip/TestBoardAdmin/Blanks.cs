﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestBoardAdmin
{
    public partial class Blanks : Form
    {
        public Blanks()
        {
            InitializeComponent();
        }

        private void button_Blanks_ADD_Click(object sender, EventArgs e)
        {
            var x = session.Instance.quiz.quiz_code;

            ServiceReference.Service1Client client = new ServiceReference.Service1Client();
            client.AddBlanks(x, textBox_blanks_Question.Text, textBox_blanks_CorrectAnswer.Text);

            /*using (ExamModels obj = new ExamModels())
            {

                var x = session.Instance.quiz.quiz_code;
                int qsid = obj.Questions.Select(a => a.question_id).Max() + 1;
                int qzid = obj.Quizs.Where(a => a.quiz_code == (x)).Select(a => a.quiz_id).First();

                Question ques1 = new Question();
                ques1.quiz_id = qzid;
                ques1.question_id = qsid;
                ques1.question_statement = textBox_blanks_Question.Text;
                ques1.correct_answer = textBox_blanks_CorrectAnswer.Text;
                ques1.category_id = 3;
                ques1.answer = "";
                obj.Questions.Add(ques1);

                obj.SaveChanges();

            }*/

            textBox_blanks_Question.Clear();
            textBox_blanks_CorrectAnswer.Clear();
            MessageBox.Show("Question Added");
        }

        private void button_Blanks_Finish_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Quiz Added");
            this.Close();
        }
    }
}
