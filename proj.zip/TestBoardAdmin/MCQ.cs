﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestBoardAdmin
{
    public partial class MCQ : Form
    {
        public MCQ()
        {
            InitializeComponent();
        }

        private void textBox_MCQ_Option3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox_MCQ_Option2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox_MCQ_Option1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox_MCQ_Question_TextChanged(object sender, EventArgs e)
        {

        }


        private void button_MCQ_ADD_Click(object sender, EventArgs e)
        {

            using (ExamModels obj = new ExamModels())
            {

                var x = session.Instance.quiz.quiz_code;
                int qsid = obj.Questions.Select(a => a.question_id).Max() + 1;
                int qzid = obj.Quizs.Where(a => a.quiz_code == (x)).Select(a => a.quiz_id).First();

                Question ques1 = new Question();
                ques1.quiz_id = qzid;
                ques1.question_id = qsid;
                ques1.question_statement = textBox_MCQ_Question.Text;
                ques1.answer = textBox_MCQ_Option1.Text;
                ques1.correct_answer = textBox_MCQ_CorrectAnswer.Text;
                ques1.category_id =1;  
                obj.Questions.Add(ques1);

                Question ques2 = new Question();
                ques2.quiz_id = qzid;
                ques2.question_id = qsid;
                ques2.question_statement = textBox_MCQ_Question.Text;
                ques2.answer = textBox_MCQ_Option2.Text;
                ques2.correct_answer = textBox_MCQ_CorrectAnswer.Text;
                ques2.category_id = 1;
                obj.Questions.Add(ques2);

                Question ques3 = new Question();
                ques3.quiz_id = qzid;
                ques3.question_id = qsid;
                ques3.question_statement = textBox_MCQ_Question.Text;
                ques3.answer = textBox_MCQ_Option3.Text;
                ques3.correct_answer = textBox_MCQ_CorrectAnswer.Text;
                ques3.category_id = 1;
                obj.Questions.Add(ques3);

                Question ques4 = new Question();
                ques4.quiz_id = qzid;
                ques4.question_id = qsid;
                ques4.question_statement = textBox_MCQ_Question.Text;
                ques4.answer = textBox_MCQ_Option4.Text;
                ques4.correct_answer = textBox_MCQ_CorrectAnswer.Text;
                ques4.category_id = 1;
                obj.Questions.Add(ques4);

                obj.SaveChanges();
                        
            }
            
            
        }

        private void button_MCQ_Next_Click(object sender, EventArgs e)
        {
            textBox_MCQ_Question.Clear();
            textBox_MCQ_Option1.Clear();
            textBox_MCQ_Option2.Clear();
            textBox_MCQ_Option3.Clear();
            textBox_MCQ_Option4.Clear();
            textBox_MCQ_CorrectAnswer.Clear();
        }

        private void button_MCQ_Skip_Click(object sender, EventArgs e)
        {
            // Goes to true/false

            // this.Hide();
            True_False true_false = new True_False();
            true_false.Show();
        }
    }
}
