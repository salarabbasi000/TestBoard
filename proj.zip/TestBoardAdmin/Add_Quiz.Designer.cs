﻿namespace TestBoardAdmin
{
    partial class Add_Quiz
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox_Add_Quiz_Quiz_Name = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.quiz_code = new System.Windows.Forms.Label();
            this.code_btn = new System.Windows.Forms.Button();
            this.text_quiz_code_display = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Monotype Corsiva", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Maroon;
            this.label1.Location = new System.Drawing.Point(409, 11);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(312, 72);
            this.label1.TabIndex = 0;
            this.label1.Text = "ADD QUIZ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Lucida Handwriting", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(40, 177);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(203, 36);
            this.label2.TabIndex = 1;
            this.label2.Text = "Quiz Name :";
            // 
            // textBox_Add_Quiz_Quiz_Name
            // 
            this.textBox_Add_Quiz_Quiz_Name.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.textBox_Add_Quiz_Quiz_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_Add_Quiz_Quiz_Name.Location = new System.Drawing.Point(307, 179);
            this.textBox_Add_Quiz_Quiz_Name.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox_Add_Quiz_Quiz_Name.Name = "textBox_Add_Quiz_Quiz_Name";
            this.textBox_Add_Quiz_Quiz_Name.Size = new System.Drawing.Size(335, 34);
            this.textBox_Add_Quiz_Quiz_Name.TabIndex = 2;
            this.textBox_Add_Quiz_Quiz_Name.TextChanged += new System.EventHandler(this.textBox_Add_Quiz_Quiz_Name_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Lucida Handwriting", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(40, 255);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(190, 36);
            this.label4.TabIndex = 9;
            this.label4.Text = "Quiz Time :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(672, 266);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(88, 24);
            this.label5.TabIndex = 11;
            this.label5.Text = "(Minutes)";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Lucida Handwriting", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(860, 496);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(156, 43);
            this.button1.TabIndex = 12;
            this.button1.Text = "NEXT";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // quiz_code
            // 
            this.quiz_code.AutoSize = true;
            this.quiz_code.Font = new System.Drawing.Font("Lucida Handwriting", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quiz_code.Location = new System.Drawing.Point(40, 328);
            this.quiz_code.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.quiz_code.Name = "quiz_code";
            this.quiz_code.Size = new System.Drawing.Size(180, 36);
            this.quiz_code.TabIndex = 13;
            this.quiz_code.Text = "Quiz Code:";
            // 
            // code_btn
            // 
            this.code_btn.Font = new System.Drawing.Font("Lucida Handwriting", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.code_btn.Location = new System.Drawing.Point(718, 318);
            this.code_btn.Name = "code_btn";
            this.code_btn.Size = new System.Drawing.Size(271, 46);
            this.code_btn.TabIndex = 14;
            this.code_btn.Text = "Generate Code";
            this.code_btn.UseVisualStyleBackColor = true;
            this.code_btn.Click += new System.EventHandler(this.code_btn_Click);
            // 
            // text_quiz_code_display
            // 
            this.text_quiz_code_display.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_quiz_code_display.Location = new System.Drawing.Point(307, 328);
            this.text_quiz_code_display.Name = "text_quiz_code_display";
            this.text_quiz_code_display.Size = new System.Drawing.Size(327, 34);
            this.text_quiz_code_display.TabIndex = 15;
            this.text_quiz_code_display.TextChanged += new System.EventHandler(this.text_quiz_code_display_TextChanged);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "";
            this.dateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(307, 257);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.ShowUpDown = true;
            this.dateTimePicker1.Size = new System.Drawing.Size(335, 34);
            this.dateTimePicker1.TabIndex = 16;
            this.dateTimePicker1.Value = new System.DateTime(2019, 12, 1, 16, 56, 20, 0);
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // Add_Quiz
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.text_quiz_code_display);
            this.Controls.Add(this.code_btn);
            this.Controls.Add(this.quiz_code);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox_Add_Quiz_Quiz_Name);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Add_Quiz";
            this.Text = "ADD QUIZ";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox_Add_Quiz_Quiz_Name;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label quiz_code;
        private System.Windows.Forms.Button code_btn;
        private System.Windows.Forms.TextBox text_quiz_code_display;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
    }
}