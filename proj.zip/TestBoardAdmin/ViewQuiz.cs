﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestBoardAdmin
{
    public partial class ViewQuiz : Form
    {
        public ViewQuiz()
        {
            InitializeComponent();

            var x = session.Instance.user.t_id;
            ServiceReference.Service1Client client = new ServiceReference.Service1Client();
            Tuple<string[], string[], TimeSpan[]> r = client.QuizList(x);


            string[] name = r.Item1;
            string[] code = r.Item2;
            TimeSpan[] time = r.Item3;

            List<Quiz> q = new List<Quiz>();
            for (int i = 0; i < name.Count(); i++)
            {
                Quiz q1 = new Quiz();
                q1.quiz_name = name[i];
                q1.quiz_code = code[i];
                q1.time = time[i];
                q.Add(q1);
            }

            grid_quiz_list.DataSource = q;



           // ExamModels obj = new ExamModels();
            
           // grid_quiz_list.DataSource = obj.Quizs.Where(a=> a.teacher_id==x).Select( a => new { a.quiz_name,a.quiz_code,a.time }).ToList();
        }
    }
}
