﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestBoardAdmin
{
    public partial class QuizResults : Form
    {
        public QuizResults()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void viewquiz_btn_Click(object sender, EventArgs e)
        {
            string code;
            code = text_code.Text;
            ResultList result = new ResultList(code);
            result.Show();
        }
    }
}
