﻿namespace TestBoardAdmin
{
    partial class MCQ
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox_MCQ_Question = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_MCQ_Option1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox_MCQ_Option2 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox_MCQ_Option3 = new System.Windows.Forms.TextBox();
            this.textBox_MCQ_Option4 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox_MCQ_CorrectAnswer = new System.Windows.Forms.TextBox();
            this.button_MCQ_Next = new System.Windows.Forms.Button();
            this.button_MCQ_Skip = new System.Windows.Forms.Button();
            this.button_MCQ_ADD = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Monotype Corsiva", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Maroon;
            this.label1.Location = new System.Drawing.Point(257, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(260, 57);
            this.label1.TabIndex = 0;
            this.label1.Text = "ADD MCQ\'s";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Lucida Handwriting", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(14, 139);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 21);
            this.label2.TabIndex = 1;
            this.label2.Text = "Question :";
            // 
            // textBox_MCQ_Question
            // 
            this.textBox_MCQ_Question.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.textBox_MCQ_Question.Location = new System.Drawing.Point(209, 116);
            this.textBox_MCQ_Question.Multiline = true;
            this.textBox_MCQ_Question.Name = "textBox_MCQ_Question";
            this.textBox_MCQ_Question.Size = new System.Drawing.Size(508, 97);
            this.textBox_MCQ_Question.TabIndex = 2;
            this.textBox_MCQ_Question.TextChanged += new System.EventHandler(this.textBox_MCQ_Question_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Lucida Handwriting", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(17, 231);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 21);
            this.label3.TabIndex = 3;
            this.label3.Text = "Option 1 :";
            // 
            // textBox_MCQ_Option1
            // 
            this.textBox_MCQ_Option1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.textBox_MCQ_Option1.Location = new System.Drawing.Point(209, 231);
            this.textBox_MCQ_Option1.Name = "textBox_MCQ_Option1";
            this.textBox_MCQ_Option1.Size = new System.Drawing.Size(280, 20);
            this.textBox_MCQ_Option1.TabIndex = 4;
            this.textBox_MCQ_Option1.TextChanged += new System.EventHandler(this.textBox_MCQ_Option1_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Lucida Handwriting", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(17, 271);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(98, 21);
            this.label4.TabIndex = 5;
            this.label4.Text = "Option 2 :";
            // 
            // textBox_MCQ_Option2
            // 
            this.textBox_MCQ_Option2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.textBox_MCQ_Option2.Location = new System.Drawing.Point(209, 271);
            this.textBox_MCQ_Option2.Name = "textBox_MCQ_Option2";
            this.textBox_MCQ_Option2.Size = new System.Drawing.Size(280, 20);
            this.textBox_MCQ_Option2.TabIndex = 4;
            this.textBox_MCQ_Option2.TextChanged += new System.EventHandler(this.textBox_MCQ_Option2_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Lucida Handwriting", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(17, 312);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(98, 21);
            this.label5.TabIndex = 5;
            this.label5.Text = "Option 3 :";
            // 
            // textBox_MCQ_Option3
            // 
            this.textBox_MCQ_Option3.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.textBox_MCQ_Option3.Location = new System.Drawing.Point(209, 312);
            this.textBox_MCQ_Option3.Name = "textBox_MCQ_Option3";
            this.textBox_MCQ_Option3.Size = new System.Drawing.Size(280, 20);
            this.textBox_MCQ_Option3.TabIndex = 6;
            this.textBox_MCQ_Option3.TextChanged += new System.EventHandler(this.textBox_MCQ_Option3_TextChanged);
            // 
            // textBox_MCQ_Option4
            // 
            this.textBox_MCQ_Option4.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.textBox_MCQ_Option4.Location = new System.Drawing.Point(209, 351);
            this.textBox_MCQ_Option4.Name = "textBox_MCQ_Option4";
            this.textBox_MCQ_Option4.Size = new System.Drawing.Size(280, 20);
            this.textBox_MCQ_Option4.TabIndex = 7;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Lucida Handwriting", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(17, 349);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(98, 21);
            this.label6.TabIndex = 8;
            this.label6.Text = "Option 4 :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Lucida Handwriting", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(17, 401);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(153, 21);
            this.label7.TabIndex = 9;
            this.label7.Text = "Correct Answer :";
            // 
            // textBox_MCQ_CorrectAnswer
            // 
            this.textBox_MCQ_CorrectAnswer.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.textBox_MCQ_CorrectAnswer.Location = new System.Drawing.Point(209, 401);
            this.textBox_MCQ_CorrectAnswer.Name = "textBox_MCQ_CorrectAnswer";
            this.textBox_MCQ_CorrectAnswer.Size = new System.Drawing.Size(280, 20);
            this.textBox_MCQ_CorrectAnswer.TabIndex = 10;
            // 
            // button_MCQ_Next
            // 
            this.button_MCQ_Next.Font = new System.Drawing.Font("Lucida Handwriting", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_MCQ_Next.Location = new System.Drawing.Point(613, 475);
            this.button_MCQ_Next.Name = "button_MCQ_Next";
            this.button_MCQ_Next.Size = new System.Drawing.Size(75, 31);
            this.button_MCQ_Next.TabIndex = 11;
            this.button_MCQ_Next.Text = "NEXT";
            this.button_MCQ_Next.UseVisualStyleBackColor = true;
            this.button_MCQ_Next.Click += new System.EventHandler(this.button_MCQ_Next_Click);
            // 
            // button_MCQ_Skip
            // 
            this.button_MCQ_Skip.Font = new System.Drawing.Font("Lucida Handwriting", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_MCQ_Skip.Location = new System.Drawing.Point(717, 475);
            this.button_MCQ_Skip.Name = "button_MCQ_Skip";
            this.button_MCQ_Skip.Size = new System.Drawing.Size(75, 31);
            this.button_MCQ_Skip.TabIndex = 12;
            this.button_MCQ_Skip.Text = "SKIP";
            this.button_MCQ_Skip.UseVisualStyleBackColor = true;
            this.button_MCQ_Skip.Click += new System.EventHandler(this.button_MCQ_Skip_Click);
            // 
            // button_MCQ_ADD
            // 
            this.button_MCQ_ADD.Font = new System.Drawing.Font("Lucida Handwriting", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_MCQ_ADD.Location = new System.Drawing.Point(507, 475);
            this.button_MCQ_ADD.Name = "button_MCQ_ADD";
            this.button_MCQ_ADD.Size = new System.Drawing.Size(75, 31);
            this.button_MCQ_ADD.TabIndex = 13;
            this.button_MCQ_ADD.Text = "ADD";
            this.button_MCQ_ADD.UseVisualStyleBackColor = true;
            this.button_MCQ_ADD.Click += new System.EventHandler(this.button_MCQ_ADD_Click);
            // 
            // MCQ
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(804, 508);
            this.Controls.Add(this.button_MCQ_ADD);
            this.Controls.Add(this.button_MCQ_Skip);
            this.Controls.Add(this.button_MCQ_Next);
            this.Controls.Add(this.textBox_MCQ_CorrectAnswer);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textBox_MCQ_Option4);
            this.Controls.Add(this.textBox_MCQ_Option3);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBox_MCQ_Option2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox_MCQ_Option1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBox_MCQ_Question);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "MCQ";
            this.Text = "MCQ";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox_MCQ_Question;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox_MCQ_Option1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox_MCQ_Option2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox_MCQ_Option3;
        private System.Windows.Forms.TextBox textBox_MCQ_Option4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox_MCQ_CorrectAnswer;
        private System.Windows.Forms.Button button_MCQ_Next;
        private System.Windows.Forms.Button button_MCQ_Skip;
        private System.Windows.Forms.Button button_MCQ_ADD;
    }
}