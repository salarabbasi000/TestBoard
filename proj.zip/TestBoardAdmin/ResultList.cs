﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestBoardAdmin
{
    public partial class ResultList : Form
    {
        public ResultList(string code)
        {
            InitializeComponent();
            /*
            ExamModels obj = new ExamModels();
            var x = session.Instance.user.t_id;
            grid_results.DataSource = (from q in obj.Quizs
                                       join r in obj.Results on q.quiz_id equals r.quiz_id
                                       join s in obj.Students on r.stud_id equals s.s_id
                                       where (q.quiz_code == code) && (q.teacher_id==x)
                                       select new { s.s_name, r.obtained, r.total }).ToList();
            */

            ServiceReference.Service1Client client = new ServiceReference.Service1Client();
            var x = session.Instance.user.t_id;
            //MessageBox.Show(x.ToString()+" "+code);
            Tuple<string[],int[],int[]> r= client.ResultList((int)x,code);

            string[] name= r.Item1;
            int[] obt= r.Item2;
            int[] total= r.Item3;

            List<StudentResult> sr = new List<StudentResult>();
            for (int i = 0; i < name.Count(); i++)
            {
                StudentResult r1 = new StudentResult();
                r1.name = name[i];
                r1.obtained = obt[i];
                r1.total = total[i];
                sr.Add(r1);
            }

            grid_results.DataSource = sr;
        }
    }
}
