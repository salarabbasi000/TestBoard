﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestBoardAdmin
{
    class StudentResult
    {
        public string name;
        public int obtained;
        public int total;
    }
}
