﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestBoardAdmin
{
    public partial class Chose_Action : Form
    {
        public Chose_Action()
        {
            InitializeComponent();
        }

        private void button_chose_option_add_quiz_Click(object sender, EventArgs e)
        {
            //this.Hide();
            Add_Quiz add_quiz = new Add_Quiz();
            add_quiz.Show();
        }

        private void button_chose_action_view_results_Click(object sender, EventArgs e)
        {
            // View results..
            QuizResults quizresults = new QuizResults();
            quizresults.Show();
        }

        private void button_chose_action_view_added_quizes_Click(object sender, EventArgs e)
        {
            ViewQuiz view_quiz = new ViewQuiz();
            view_quiz.Show();

        }

        private void Chose_Action_Load(object sender, EventArgs e)
        {
            if(session.Instance.isLoggedIn)
            {
                this.Text = "Logged in User: " + session.Instance.user.t_id;
            }
            else
            {
                this.Text = "No user Logged In";
            }
        }
    }
}
