﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestBoardAdmin
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void button_Login_Click(object sender, EventArgs e)
        {
            ServiceReference.Service1Client client = new ServiceReference.Service1Client();

            Teacher t = new Teacher()
            {
                t_email = textBox_Login_Email.Text,
                t_password = textBox_Login_Pass.Text,
            };

            int res = client.TeacherLogin(textBox_Login_Email.Text, textBox_Login_Pass.Text);

            if (res==1)
            {
                MessageBox.Show("Logged In succesfully");
                textBox_Login_Email.Clear();
                textBox_Login_Pass.Clear();

                session.Instance.user = t;
                Chose_Action chose_action = new Chose_Action();
                chose_action.Show();
            }
            else
            {
                MessageBox.Show("Email or Password Incorrect");
                textBox_Login_Pass.Clear();
            }

            /*
            using (ExamModels obj = new ExamModels())
            {
                Teacher t = new Teacher
                {

                    t_email = textBox_Login_Email.Text,
                    t_password = textBox_Login_Pass.Text,
  
                };

                t = obj.Teachers.Where(a => a.t_email == t.t_email && a.t_password == t.t_password).FirstOrDefault();
                if (t != null)
                {
                    
                    
                    MessageBox.Show("Logged In succesfully");
                    textBox_Login_Email.Clear();
                    textBox_Login_Pass.Clear();
                    
                    session.Instance.user = t;
                    Chose_Action chose_action = new Chose_Action();
                    chose_action.Show();
                }
                else
                {
                    MessageBox.Show("Email or Password Incorrect");
                    textBox_Login_Pass.Clear();
                }
            }
            */
        }

        private void textBox_Login_Email_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox_Login_Pass_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
