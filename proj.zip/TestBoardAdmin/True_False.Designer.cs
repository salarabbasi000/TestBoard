﻿namespace TestBoardAdmin
{
    partial class True_False
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_True_False_Question = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.button_True_False_ADD = new System.Windows.Forms.Button();
            this.button_True_False_Skip = new System.Windows.Forms.Button();
            this.button_True_False_Next = new System.Windows.Forms.Button();
            this.radioButton_True_False_True = new System.Windows.Forms.RadioButton();
            this.radioButton_True_False_False = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Monotype Corsiva", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Maroon;
            this.label1.Location = new System.Drawing.Point(199, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(421, 57);
            this.label1.TabIndex = 1;
            this.label1.Text = "ADD TRUE/FALSE";
            // 
            // textBox_True_False_Question
            // 
            this.textBox_True_False_Question.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.textBox_True_False_Question.Location = new System.Drawing.Point(209, 121);
            this.textBox_True_False_Question.Multiline = true;
            this.textBox_True_False_Question.Name = "textBox_True_False_Question";
            this.textBox_True_False_Question.Size = new System.Drawing.Size(508, 92);
            this.textBox_True_False_Question.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Lucida Handwriting", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(14, 144);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 21);
            this.label2.TabIndex = 3;
            this.label2.Text = "Question :";
            // 
            // button_True_False_ADD
            // 
            this.button_True_False_ADD.Font = new System.Drawing.Font("Lucida Handwriting", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_True_False_ADD.Location = new System.Drawing.Point(499, 445);
            this.button_True_False_ADD.Name = "button_True_False_ADD";
            this.button_True_False_ADD.Size = new System.Drawing.Size(75, 31);
            this.button_True_False_ADD.TabIndex = 16;
            this.button_True_False_ADD.Text = "ADD";
            this.button_True_False_ADD.UseVisualStyleBackColor = true;
            this.button_True_False_ADD.Click += new System.EventHandler(this.button_True_False_ADD_Click);
            // 
            // button_True_False_Skip
            // 
            this.button_True_False_Skip.Font = new System.Drawing.Font("Lucida Handwriting", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_True_False_Skip.Location = new System.Drawing.Point(715, 445);
            this.button_True_False_Skip.Name = "button_True_False_Skip";
            this.button_True_False_Skip.Size = new System.Drawing.Size(75, 31);
            this.button_True_False_Skip.TabIndex = 15;
            this.button_True_False_Skip.Text = "SKIP";
            this.button_True_False_Skip.UseVisualStyleBackColor = true;
            this.button_True_False_Skip.Click += new System.EventHandler(this.button_True_False_Skip_Click);
            // 
            // button_True_False_Next
            // 
            this.button_True_False_Next.Font = new System.Drawing.Font("Lucida Handwriting", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_True_False_Next.Location = new System.Drawing.Point(605, 445);
            this.button_True_False_Next.Name = "button_True_False_Next";
            this.button_True_False_Next.Size = new System.Drawing.Size(75, 31);
            this.button_True_False_Next.TabIndex = 14;
            this.button_True_False_Next.Text = "NEXT";
            this.button_True_False_Next.UseVisualStyleBackColor = true;
            this.button_True_False_Next.Click += new System.EventHandler(this.button_True_False_Next_Click);
            // 
            // radioButton_True_False_True
            // 
            this.radioButton_True_False_True.AutoSize = true;
            this.radioButton_True_False_True.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton_True_False_True.Location = new System.Drawing.Point(209, 275);
            this.radioButton_True_False_True.Name = "radioButton_True_False_True";
            this.radioButton_True_False_True.Size = new System.Drawing.Size(54, 20);
            this.radioButton_True_False_True.TabIndex = 17;
            this.radioButton_True_False_True.TabStop = true;
            this.radioButton_True_False_True.Text = "True";
            this.radioButton_True_False_True.UseVisualStyleBackColor = true;
            this.radioButton_True_False_True.CheckedChanged += new System.EventHandler(this.radioButton_True_False_True_CheckedChanged);
            // 
            // radioButton_True_False_False
            // 
            this.radioButton_True_False_False.AutoSize = true;
            this.radioButton_True_False_False.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton_True_False_False.Location = new System.Drawing.Point(352, 275);
            this.radioButton_True_False_False.Name = "radioButton_True_False_False";
            this.radioButton_True_False_False.Size = new System.Drawing.Size(60, 20);
            this.radioButton_True_False_False.TabIndex = 18;
            this.radioButton_True_False_False.TabStop = true;
            this.radioButton_True_False_False.Text = "False";
            this.radioButton_True_False_False.UseVisualStyleBackColor = true;
            this.radioButton_True_False_False.CheckedChanged += new System.EventHandler(this.radioButton_True_False_False_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Lucida Handwriting", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(14, 274);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(153, 21);
            this.label3.TabIndex = 19;
            this.label3.Text = "Correct Answer :";
            // 
            // True_False
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(806, 488);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.radioButton_True_False_False);
            this.Controls.Add(this.radioButton_True_False_True);
            this.Controls.Add(this.button_True_False_ADD);
            this.Controls.Add(this.button_True_False_Skip);
            this.Controls.Add(this.button_True_False_Next);
            this.Controls.Add(this.textBox_True_False_Question);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "True_False";
            this.Text = "True_False";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox_True_False_Question;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button_True_False_ADD;
        private System.Windows.Forms.Button button_True_False_Skip;
        private System.Windows.Forms.Button button_True_False_Next;
        private System.Windows.Forms.RadioButton radioButton_True_False_True;
        private System.Windows.Forms.RadioButton radioButton_True_False_False;
        private System.Windows.Forms.Label label3;
    }
}