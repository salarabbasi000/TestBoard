﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestBoardAdmin
{
    public partial class True_False : Form
    {
        public True_False()
        {
            InitializeComponent();
        }

        private void radioButton_True_False_True_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton_True_False_False_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button_True_False_ADD_Click(object sender, EventArgs e)
        {
            using (ExamModels obj = new ExamModels())
            {
                var x = session.Instance.quiz.quiz_code;
                int qsid = obj.Questions.Select(a => a.question_id).Max() + 1;
                int qzid = obj.Quizs.Where(a => a.quiz_code == (x)).Select(a => a.quiz_id).First();

                Question ques1 = new Question();
                Question ques2 = new Question();
                ques1.quiz_id = qzid;
                ques1.question_id = qsid;
                ques1.question_statement = textBox_True_False_Question.Text;
                if (radioButton_True_False_False.Checked)
                {
                    ques1.correct_answer = radioButton_True_False_False.Text.ToLower();
                }
                else if (radioButton_True_False_True.Checked)
                {
                    ques1.correct_answer = radioButton_True_False_True.Text.ToLower();
                }
                else
                {
                    MessageBox.Show("Select Answer");
                }
                ques1.answer = "true";
                ques1.category_id = 2;
                obj.Questions.Add(ques1);

                ques2.quiz_id = qzid;
                ques2.question_id = qsid;
                ques2.question_statement = textBox_True_False_Question.Text;
                if (radioButton_True_False_False.Checked)
                {
                    ques2.correct_answer = radioButton_True_False_False.Text.ToLower();
                }
                else if (radioButton_True_False_True.Checked)
                {
                    ques2.correct_answer = radioButton_True_False_True.Text.ToLower();
                }
                else
                {
                    MessageBox.Show("Select Correct Answer");
                }
                ques2.answer = "false";
                ques2.category_id = 2;
                obj.Questions.Add(ques2);

                obj.SaveChanges();


            }

            

            textBox_True_False_Question.Clear();
            MessageBox.Show("Question Added");



        }

        private void button_True_False_Next_Click(object sender, EventArgs e)
        {
            
            Blanks blanks = new Blanks();
            blanks.Show();

        }

        private void button_True_False_Skip_Click(object sender, EventArgs e)
        {
            
            Blanks blanks = new Blanks();
            blanks.Show();
        }
    }
}
