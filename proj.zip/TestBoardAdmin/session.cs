﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestBoardAdmin
{
    public class session
    {
        #region Define as Singleton
        private static session _Instance;
        public static session Instance
        {
            get
            {
                if(_Instance == null)
                {
                    _Instance = new session();
                }

                return (_Instance);
            }
        }

        private session()
        {

        }
        #endregion

        public Teacher user { get; set; }
        public Quiz quiz { get; set; }
 

        public bool isLoggedIn
        {
            get
            {
                if (user != null)
                    return true;
                else return false;
            }
        }
        
    }
}
