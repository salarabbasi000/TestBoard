﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestBoardAdmin
{
    public partial class SignUP : Form
    {
        public SignUP()
        {
            InitializeComponent();
        }

        private void textBox_SignUp_Name_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox_Signup_Email_TextChanged(object sender, EventArgs e)
        {

        }

        private void radioButton_Signup_Male_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton_Signup_Female_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void textBox_Signup_ConPass_TextChanged(object sender, EventArgs e)
        {

        }

        private void button_SignUP_Click(object sender, EventArgs e)
        {
            ServiceReference.Service1Client client = new ServiceReference.Service1Client();

            Teacher t = new Teacher() {
                t_name = textBox_SignUp_Name.Text,
                t_email = textBox_Signup_Email.Text,
                t_password = textBox_SignUp_Pass.Text,
                c_password = textBox_Signup_ConPass.Text,
            };

            int res=client.TeacherSignUp(textBox_SignUp_Name.Text, textBox_Signup_Email.Text,
                textBox_SignUp_Pass.Text, textBox_Signup_ConPass.Text,
                radioButton_Signup_Male.Checked, radioButton_Signup_Female.Checked,
                radioButton_Signup_Male.Text, radioButton_Signup_Female.Text);
            if (res==4)
            {
                MessageBox.Show("Mail already exist");
            }
            else if(res == 3)
            {
                MessageBox.Show("Register with NU-mail");
            }
            else if(res == 2)
            {
                MessageBox.Show("Password not Equal");
                
            }
            else
            {
                MessageBox.Show("Successfully registered");
                session.Instance.user = t;
                Login login = new Login();
                login.Show();
            }
            /*
            using (ExamModels obj = new ExamModels())
            {
                Teacher t = new Teacher
                {
                    t_name = textBox_SignUp_Name.Text,
                    t_email = textBox_Signup_Email.Text,
                    t_password = textBox_SignUp_Pass.Text,
                    c_password = textBox_Signup_ConPass.Text,
                };

                if(radioButton_Signup_Male.Checked)
                {
                    t.gender = radioButton_Signup_Male.Text;
                }
                else if (radioButton_Signup_Female.Checked)
                {
                    t.gender = radioButton_Signup_Female.Text;
                }
                else
                {
                    MessageBox.Show("Select Gender");
                }


                var y = obj.Teachers.Where(a => a.t_email == t.t_email);
                if (y.Count() == 0)
                {
                    if(t.t_email.Contains("@nu.edu.pk"))
                    {
                            if (t.t_password == t.c_password)
                            {
                                //t.s_age = DateTime.Now.Year - Convert.ToDateTime(t.s_dob).Year;
                                obj.Teachers.Add(t);
                                obj.SaveChanges();
                                textBox_SignUp_Name.Clear();
                                textBox_Signup_Email.Clear();
                                textBox_SignUp_Pass.Clear();
                                textBox_Signup_ConPass.Clear();
                        
                                //return 1;
                                MessageBox.Show("Successfully registered");
                                //this.Close();
                                session.Instance.user = t;
                                Login login = new Login();
                                login.Show();
                            }
                            else
                            {
                                //return 2;
                                MessageBox.Show("Password not Equal");
                            }
                    }
                    else
                    {
                        //return 3;
                        MessageBox.Show("Register with NU-mail");
                    }
                }
                else
                {
                    //return 4;
                    MessageBox.Show("Mail already exist");
                }
                //Close();
            }
            */

            //this.Close();

        }

        private void SignUP_Load(object sender, EventArgs e)
        {

        }

        private void link_login_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //Close();
            Login login = new Login();
            login.Show();
            


        }
    }
}
