﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ExamClient.Models
{
    public class Student
    {
        public string s_name { get; set; }
        public string s_email { get; set; }
        public string s_password { get; set; }
        public string c_password { get; set; }
        public string s_gender { get; set; }
        public Nullable<System.DateTime> s_dob { get; set; }
    }
}