﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ExamClient.Models
{
    public class Question
    {
        public int question_id { get; set; }
        public int quiz_id { get; set; }
        public string quiz_name { get; set; }
        public TimeSpan completiontime { get; set; }
        public string question_statement { get; set; }
        public string answer { get; set; }
        public string correct_answer { get; set; }
        public Nullable<int> category_id { get; set; }
    }
}