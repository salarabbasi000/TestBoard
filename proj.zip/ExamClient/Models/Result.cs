﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ExamClient.Models
{
    public class Result
    {
        public int quiz_id { get; set; }
        public string quiz_name { get; set; }
        public int stud_id { get; set; }
        public Nullable<int> obtained { get; set; }
        public Nullable<int> total { get; set; }
        public Nullable<System.DateTime> submission_time { get; set; }
    }
}