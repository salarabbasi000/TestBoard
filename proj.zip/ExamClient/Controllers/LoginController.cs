﻿using ExamClient.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ExamClient.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(Student x)
        {
            /*using (ExamModels s = new ExamModels())
            {
                var y = s.Students.Where(a => a.s_email == x.s_email && a.s_password == x.s_password);
                if (y.Count() > 0)
                {
                    ViewBag.SuccessMessage = "Logged In";
                    Session["UserID"] = x.s_email;
                    return RedirectToAction("Index", "Home");

                }
                else
                {
                    ViewBag.SuccessMessage = "Wrong Email or Password";
                }
            }*/

            ServiceReference.Service1Client service = new ServiceReference.Service1Client();

            ServiceReference.Student y = new ServiceReference.Student();
            y.s_email = x.s_email;
            y.s_password = x.s_password;
            int z=service.StudentLogin(y);
            if (z == 1)
            {
                ViewBag.SuccessMessage = "Logged In";
                Session["UserID"] = x.s_email;
                return RedirectToAction("Index", "Home");
            }
            else if (z == 0)
            {
                ViewBag.SuccessMessage = "Wrong Email or Password";
            }

            ModelState.Clear();
            return View("Index", new Student());
        }

        public ActionResult Logout()
        {
            Session.Abandon();
            return RedirectToAction("Index", "Login");
        }
    }
}