﻿using ExamClient.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ExamClient.Controllers
{
    public class HomeController : Controller
    {
        ServiceReference.Service1Client service = new ServiceReference.Service1Client();

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        public ActionResult JoinQuiz()
        {
            return View();
        }

        public ActionResult StartQuiz(string usercode)
        {
            string aq = Convert.ToString(Session["UserID"]);

            try
            {
                

                Tuple<int[], int[], string[], int[], string[], string[],TimeSpan[]> ques= service.StartQuiz(aq, usercode);

                
                int []quiz_id = ques.Item1;
                int[] question_id = ques.Item2;
                string[] answer = ques.Item3;
                int[] category_id = ques.Item4;
                string[] correct_answer = ques.Item5;
                string[] question_statement = ques.Item6;

                TimeSpan[] completiontime = ques.Item7;
                int i;
                
                List<Question> qlist = new List<Question>();

                for (i = 0; i < question_id.Count(); i++)
                {
                    Question q = new Question();
                    q.quiz_id = quiz_id[i];
                    q.question_id = question_id[i];
                    q.answer = answer[i];
                    q.category_id = category_id[i];
                    q.correct_answer = correct_answer[i];
                    q.question_statement = question_statement[i];
                    q.completiontime = completiontime[i];
                    qlist.Add(q);
                }

                if (ques==null)
                {
                    return RedirectToAction("Index", "Home");
                }
                return View(qlist);
                
                
                //return Content(question_statement[25].ToString());

                /*
                ExamModels s = new ExamModels();

                var r = s.Students.Where(c => c.s_email == aq).First();

                var q = s.Quizs.Where(c => c.quiz_code == usercode).First();

                var x = s.Results.Where(c => c.stud_id == r.s_id && c.quiz_id == q.quiz_id);

                if (x.Count() > 0)
                {
                    return RedirectToAction("Index", "Home");
                }

                var ques = s.Questions.Where(l => l.quiz_id == q.quiz_id);

                return View(ques);*/
            }
            catch (Exception e)
            {
                ViewBag.QuizMessage = "Invalid code";
                return RedirectToAction("JoinQuiz", "Home");
            }
        }

        public ActionResult Gradebook()
        {
            string aq = Convert.ToString(Session["UserID"]);
            /*
            ExamModels s = new ExamModels();

            var x = s.Students.Where(a => a.s_email == aq).Select(a => a.s_id).First();

            var z = s.Results.Where(a => a.stud_id == x).OrderByDescending(a => a.submission_time).ToList();

            return View(z);
            */

            Tuple<string[],int[],int[],DateTime[]> z = service.GradeBook(aq);

            string[] quiz_name = z.Item1;
            int[] total = z.Item2;
            int[] obtained = z.Item3;
            DateTime[] submission_time = z.Item4;
            int i = 0;
            
            List<Result> r2 = new List<Result>();

            for (i = 0;i<quiz_name.Count(); i++)
            {
                Result r = new Result();
                r.quiz_name = quiz_name[i];
                r.obtained = obtained[i];
                r.total = total[i];
                r.submission_time = submission_time[i];
                r2.Add(r);
            }
            //return Content(quiz_name[1]);
            return View(r2);
        }

        public ActionResult Scores(FormCollection fc, string quizid)
        {
            string aq = Convert.ToString(Session["UserID"]);
            int id = Int32.Parse(quizid);

            /*ExamModels s = new ExamModels();

            string iss = "";
            
            var ques = s.Questions.Where(x => x.quiz_id == id).OrderBy(x => x.question_id).Select(x => x.correct_answer);
            var uniqueques = ques.ToList().Distinct();
            */

            //return Content(ques1);
            var uniqueques = service.GetCorrectAns(quizid);

            int i = 1;
            int obt = 0;
            int wrong = 0;
            string iss = "";

            

            foreach (var que in uniqueques)
            {

                if (que.ToLower() == fc["ques" + i].ToLower())
                {
                    obt++;
                }
                else
                {
                    wrong++;
                }
                iss += (que.ToLower() + "==" + fc["ques" + i].ToLower() + ";");
                i++;
            }

            //return Content(iss);
            service.SaveResult(aq, id, wrong,obt);

            /*
            var y = s.Students.Where(a => a.s_email == aq).Select(a => a.s_id).First();

            Result r = new Result();
            r.quiz_id = id;
            r.stud_id = y;
            r.obtained = obt;
            r.total = (obt + wrong);
            r.submission_time = DateTime.Now;
            s.Results.Add(r);
            s.SaveChanges();
            */

            return RedirectToAction("Index", "Home");
            

            //return Content(iss);

        }

    }
}