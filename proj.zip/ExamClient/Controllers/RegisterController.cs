﻿using ExamClient.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ExamClient.Controllers
{
    public class RegisterController : Controller
    {
        // GET: Register
        [HttpGet]
        public ActionResult Index()
        {
            Student x = new Student();
            return View(x);
        }

        [HttpPost]
        public ActionResult Index(Student x)
        {
            /*using (ExamModels s = new ExamModels())
            {
                var y = s.Students.Where(a => a.s_email == x.s_email);
                if (y.Count() == 0)
                {
                    if (x.s_password == x.c_password)
                    {
                        if (x.s_email.Contains("nu.edu.pk"))
                        {
                            x.s_age = DateTime.Now.Year - Convert.ToDateTime(x.s_dob).Year;
                            s.Students.Add(x);
                            s.SaveChanges();
                            ViewBag.SuccessMessage = "Successful";

                            try
                            {
                                MailMessage m = new MailMessage();
                                m.To.Add(x.s_email);
                                m.From = new MailAddress("salarabbasi000@gmail.com");
                                m.Subject = "TESTBOARD";
                                m.Body = "You have successfully registered to TESTBOARD. You can take any quiz for which the code will be provided to you by your teacher.\nRegrads,\nTESTBOARD Team.";

                                SmtpClient client = new SmtpClient();
                                client.Host = "smtp.gmail.com";
                                client.Port = 587;
                                client.EnableSsl = true;
                                client.Timeout = 10000;
                                client.DeliveryMethod = SmtpDeliveryMethod.Network;
                                client.UseDefaultCredentials = false;
                                client.Credentials = new NetworkCredential("salarabbasi000@gmail.com", "dev4893webl");

                                client.Send(m);
                                client.Dispose();
                            }
                            catch (Exception e)
                            {
                            }


                            return RedirectToAction("Index", "Login");
                        }
                        else
                        {
                            ViewBag.SuccessMessage = "Use NU Email Only";
                        }
                    }
                    else
                    {
                        ViewBag.SuccessMessage = "Password does not match";
                    }
                }
                else
                {
                    ViewBag.SuccessMessage = "Account with this email already exists";
                }

            }
            */
            
            ServiceReference.Service1Client service = new ServiceReference.Service1Client();

            ServiceReference.Student y = new ServiceReference.Student();
            y.s_name= x.s_name;
            y.s_email= x.s_email;
            y.s_dob= x.s_dob;
            y.s_gender = x.s_gender;
            y.s_password= x.s_password;
            y.c_password= x.c_password;
            
            int z=service.StudentRegister(y);

            if (z == 1)
            {
                return RedirectToAction("Index", "Login");
            }
            else if (z == 2)
            {
                ViewBag.SuccessMessage = "Use NU Email Only";
            }
            else if (z == 3)
            {
                ViewBag.SuccessMessage = "Password does not match";
            }
            else{
                ViewBag.SuccessMessage = "Account with this email already exists";
                
            }
            ModelState.Clear();
            return View("Index", new Student());
        }
    }
}