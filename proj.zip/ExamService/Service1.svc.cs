﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace ExamService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class Service1 : IService1
    {
        public string GetData(int value)
        {
            return string.Format("You entered: {0}", value);
        }

        public CompositeType GetDataUsingDataContract(CompositeType composite)
        {
            if (composite == null)
            {
                throw new ArgumentNullException("composite");
            }
            if (composite.BoolValue)
            {
                composite.StringValue += "Suffix";
            }
            return composite;
        }







        public int StudentRegister(Student x)
        {
            using (ExamModels s = new ExamModels())
            {
                var y = s.Students.Where(a => a.s_email == x.s_email);
                if (y.Count() == 0)
                {
                    if (x.s_password == x.c_password)
                    {
                        if (x.s_email.Contains("nu.edu.pk"))
                        {
                            x.s_age = DateTime.Now.Year - Convert.ToDateTime(x.s_dob).Year;
                            s.Students.Add(x);
                            s.SaveChanges();

                            try
                            {
                                MailMessage m = new MailMessage();
                                m.To.Add(x.s_email);
                                m.From = new MailAddress("salarabbasi000@gmail.com");
                                m.Subject = "TESTBOARD";
                                m.Body = "You have successfully registered to TESTBOARD. You can take any quiz for which the code will be provided to you by your teacher.\nRegrads,\nTESTBOARD Team.";

                                SmtpClient client = new SmtpClient();
                                client.Host = "smtp.gmail.com";
                                client.Port = 587;
                                client.EnableSsl = true;
                                client.Timeout = 10000;
                                client.DeliveryMethod = SmtpDeliveryMethod.Network;
                                client.UseDefaultCredentials = false;
                                client.Credentials = new NetworkCredential("salarabbasi000@gmail.com", "dev4893webl");

                                client.Send(m);
                                client.Dispose();
                            }
                            catch (Exception e)
                            { }
                            
                            return 1;
                        }
                        else
                        {
                            return 2;
                        }
                    }
                    else
                    {
                        return 3;
                    }
                }
                else
                {
                    return 4;
                }

            }
        }

        public int StudentLogin(Student x)
        {
            using (ExamModels s = new ExamModels())
            {
                var y = s.Students.Where(a => a.s_email == x.s_email && a.s_password == x.s_password);
                if (y.Count() > 0)
                {
                    //ViewBag.SuccessMessage = "Logged In";
                    //Session["UserID"] = x.s_email;
                    return 1;
                }
                else
                {
                    //ViewBag.SuccessMessage = "Wrong Email or Password";
                    return 0;
                }
            }
        }

        public int TeacherRegister(Teacher x)
        {
            using (ExamModels s = new ExamModels())
            {
                var y = s.Teachers.Where(a => a.t_email == x.t_email);
                if (y.Count() == 0)
                {
                    if (x.t_password == x.c_password)
                    {
                        if (x.t_email.Contains("nu.edu.pk"))
                        {
                            //x.t_age = DateTime.Now.Year - Convert.ToDateTime(x.s_dob).Year;
                            s.Teachers.Add(x);
                            s.SaveChanges();

                            try
                            {
                                MailMessage m = new MailMessage();
                                m.To.Add(x.t_email);
                                m.From = new MailAddress("salarabbasi000@gmail.com");
                                m.Subject = "TESTBOARD";
                                m.Body = "You have successfully registered to TESTBOARD. You can upload any quiz for which the code will be generated. You have to share it with your students so that they can proceed.\nRegrads,\nTESTBOARD Team.";

                                SmtpClient client = new SmtpClient();
                                client.Host = "smtp.gmail.com";
                                client.Port = 587;
                                client.EnableSsl = true;
                                client.Timeout = 10000;
                                client.DeliveryMethod = SmtpDeliveryMethod.Network;
                                client.UseDefaultCredentials = false;
                                client.Credentials = new NetworkCredential("salarabbasi000@gmail.com", "dev4893webl");

                                client.Send(m);
                                client.Dispose();
                            }
                            catch (Exception e)
                            { }

                            return 1;
                        }
                        else
                        {
                            return 2;
                        }
                    }
                    else
                    {
                        return 3;
                    }
                }
                else
                {
                    return 4;
                }

            }
        }

        public int TeacherLogin(Teacher x)
        {
            using (ExamModels s = new ExamModels())
            {
                var y = s.Teachers.Where(a => a.t_email == x.t_email && a.t_password == x.t_password);
                if (y.Count() > 0)
                {
                    //ViewBag.SuccessMessage = "Logged In";
                    //Session["UserID"] = x.s_email;
                    return 1;
                }
                else
                {
                    //ViewBag.SuccessMessage = "Wrong Email or Password";
                    return 0;
                }
            }
        }

        public Tuple<string[], int[], int[], DateTime[]> GradeBook(string aq)
        {
            ExamModels s = new ExamModels();
            var x = s.Students.Where(a => a.s_email == aq).Select(a => a.s_id).First();
            
            var z = (from r in s.Results
                    join q in s.Quizs on r.quiz_id equals q.quiz_id
                    where r.stud_id == x
                    select new { q.quiz_name, r.obtained, r.total, r.submission_time }).ToList();
            //List<Result> z = s.Results.Where(a => a.stud_id == x).ToList();

            string[] quiz_name = new string[z.Count()];
            int[] total = new int[z.Count()];
            int[] obtained = new int[z.Count()];
            DateTime[] submission_time = new DateTime[z.Count()];

            //total.
            int i2 = 0;
            foreach(var i in z)
            {
                quiz_name[i2] = i.quiz_name;
                total[i2] = Convert.ToInt16(i.total);
                obtained[i2] = Convert.ToInt16(i.obtained);
                submission_time[i2] = Convert.ToDateTime(i.submission_time);
                i2++;
            }

            Tuple<string[], int[], int[], DateTime[]>t =new Tuple<string[], int[], int[], DateTime[]>(quiz_name, total, obtained, submission_time);
            return t; 
        }



        public IEnumerable<string> GetCorrectAns(string quizid)
        {
            ExamModels s = new ExamModels();
            //string iss = "";
            int id = Int32.Parse(quizid);
            //int id = Int32.Parse( Session["quizid"].ToString());
            //var ques = s.Questions.Where(x => x.quiz_id == 4).OrderBy(x => x.question_id).Select(x => x.correct_answer).Distinct();
            var ques = s.Questions.Where(x => x.quiz_id == id).OrderBy(x => x.question_id).Select(x => x.correct_answer);
            IEnumerable<string> uniqueques = ques.ToList().Distinct();
            return uniqueques;
            //var ques = from q in s.Questions orderby q.question_id select q.correct_answer;            
        }
        public bool SaveResult(string aq, int id, int wrong, int obt)
        {
            ExamModels s = new ExamModels();
            var y = s.Students.Where(a => a.s_email == aq).Select(a => a.s_id).First();

            Result r = new Result();
            r.quiz_id =id;
            r.stud_id =y;
            r.obtained=obt;
            r.total =(obt+wrong);
            r.submission_time = DateTime.Now;
            s.Results.Add(r);
            s.SaveChanges();

            return true;
        }


        public Tuple<int[], int[], string[], int[], string[], string[], TimeSpan[]> StartQuiz(string aq,string usercode)
        {
            ExamModels s = new ExamModels();

            var st = s.Students.Where(c => c.s_email == aq).First();

            var q = s.Quizs.Where(c => c.quiz_code == usercode).First();

            var x = s.Results.Where(c => c.stud_id == st.s_id && c.quiz_id == q.quiz_id);

            Tuple<int[], int[], string[], int[], string[], string[], TimeSpan[]> t;

            if (x.Count() > 0)
            {
                t = null;
                return t;
            }

            //List<Question> ques = s.Questions.Where(l => l.quiz_id == q.quiz_id).ToList();
            var ques = (from qs in s.Questions
                        join qz in s.Quizs on qs.quiz_id equals qz.quiz_id
                        where qs.quiz_id == q.quiz_id
                        select new { qs.quiz_id, qz.quiz_name, qz.time, qs.question_id, qs.answer, qs.category_id, qs.correct_answer, qs.question_statement }).ToList();
            
            /*
            int quiz_id = ques.First().quiz_id;
            string quiz_name = ques.First().quiz_name;
            DateTime completiontime = Convert.ToDateTime(ques.First().time);*/

            int[] quiz_id = new int[ques.Count()];
            int[] question_id = new int[ques.Count()];
            string[] answer = new string[ques.Count()];
            int[] category_id = new int[ques.Count()];
            string[] correct_answer = new string[ques.Count()];
            string[] question_statement =new string[ques.Count()];
            TimeSpan []completiontime = new TimeSpan[ques.Count()];

            int i2 = 0;
            foreach (var i in ques)
            {
                quiz_id[i2] = i.quiz_id;
                question_id[i2] = i.question_id;
                answer[i2] = i.answer;
                category_id[i2] = Convert.ToInt16(i.category_id);
                correct_answer[i2] = i.correct_answer;
                question_statement[i2] = i.question_statement;
                completiontime[i2] =(TimeSpan) i.time;
                i2++;
            }

            t= new Tuple<int[], int[], string[], int[], string[], string[],TimeSpan[]>
                (quiz_id, question_id, answer, category_id, correct_answer, question_statement,completiontime);
            return t;
            //return ques;
        }



        //Teacher/Admin:


        public int TeacherSignUp(string name, string email, string pass, string cpass, bool male, bool female, string m, string f)
        {
            using (ExamModels obj = new ExamModels())
            {
                Teacher t = new Teacher
                {
                    t_name = name,
                    t_email = email,
                    t_password = pass,
                    c_password = cpass,
                };

                if (male)
                {
                    t.gender = m;
                }
                else if (female)
                {
                    t.gender = f;
                }
                else
                {
                    return 0;
                }


                var y = obj.Teachers.Where(a => a.t_email == t.t_email);
                if (y.Count() == 0)
                {
                    if (t.t_email.Contains("@nu.edu.pk"))
                    {
                        if (t.t_password == t.c_password)
                        {
                            //t.s_age = DateTime.Now.Year - Convert.ToDateTime(t.s_dob).Year;
                            obj.Teachers.Add(t);
                            obj.SaveChanges();
                            //textBox_SignUp_Name.Clear();
                            //textBox_Signup_Email.Clear();
                            //textBox_SignUp_Pass.Clear();
                            //textBox_Signup_ConPass.Clear();

                            return 1;
                            //MessageBox.Show("Successfully registered");
                            
                            //session.Instance.user = t;
                            //Login login = new Login();
                            //login.Show();
                        }
                        else
                        {
                            return 2;
                        }
                    }
                    else
                    {
                        return 3;
                    }
                }
                else
                {
                    return 4;
                }
            }
        }

        public int TeacherLogin(string email,string pass)
        {
            using (ExamModels obj = new ExamModels())
            {
                Teacher t = new Teacher
                {

                    t_email = email,
                    t_password = pass,

                };

                t = obj.Teachers.Where(a => a.t_email == t.t_email && a.t_password == t.t_password).FirstOrDefault();
                if (t != null)
                {
                    return 1;
                    //textBox_Login_Email.Clear();
                    //textBox_Login_Pass.Clear();

                    //session.Instance.user = t;
                    //Chose_Action chose_action = new Chose_Action();
                    //chose_action.Show();
                }
                else
                {
                    return 2;
                    //MessageBox.Show("Email or Password Incorrect");
                    //textBox_Login_Pass.Clear();
                }
            }
        }


        public int AddMCQs(string x, string q, string ans1, string ans2, string ans3, string ans4, string c)
        {
            using (ExamModels obj = new ExamModels())
            {

                //var x = session.Instance.quiz.quiz_code;
                int qsid = obj.Questions.Select(a => a.question_id).Max() + 1;
                int qzid = obj.Quizs.Where(a => a.quiz_code == (x)).Select(a => a.quiz_id).First();

                Question ques1 = new Question();
                ques1.quiz_id = qzid;
                ques1.question_id = qsid;
                ques1.question_statement = q;
                ques1.answer = ans1;
                ques1.correct_answer = c;
                ques1.category_id = 1;
                obj.Questions.Add(ques1);

                Question ques2 = new Question();
                ques2.quiz_id = qzid;
                ques2.question_id = qsid;
                ques2.question_statement = q;
                ques2.answer = ans2;
                ques2.correct_answer = c;
                ques2.category_id = 1;
                obj.Questions.Add(ques2);

                Question ques3 = new Question();
                ques3.quiz_id = qzid;
                ques3.question_id = qsid;
                ques3.question_statement = q;
                ques3.answer = ans3;
                ques3.correct_answer = c;
                ques3.category_id = 1;
                obj.Questions.Add(ques3);

                Question ques4 = new Question();
                ques4.quiz_id = qzid;
                ques4.question_id = qsid;
                ques4.question_statement = q;
                ques4.answer = ans4;
                ques4.correct_answer = c;
                ques4.category_id = 1;
                obj.Questions.Add(ques4);

                return obj.SaveChanges();

            }
        }


        public int AddTrueFalse(string x,string q, bool t, bool f, string text_t, string text_f)
        {
            using (ExamModels obj = new ExamModels())
            {
                //var x = session.Instance.quiz.quiz_code;
                int qsid = obj.Questions.Select(a => a.question_id).Max() + 1;
                int qzid = obj.Quizs.Where(a => a.quiz_code == (x)).Select(a => a.quiz_id).First();

                Question ques1 = new Question();
                Question ques2 = new Question();
                ques1.quiz_id = qzid;
                ques1.question_id = qsid;
                ques1.question_statement = q;
                if (f)
                {
                    ques1.correct_answer = text_f.ToLower();
                }
                else if (t)
                {
                    ques1.correct_answer = text_t.ToLower();
                }
                else
                {
                    ques1.correct_answer = text_t.ToLower();
                    //MessageBox.Show("Select Answer");
                }

                ques1.answer = "true";
                ques1.category_id = 2;
                obj.Questions.Add(ques1);

                ques2.quiz_id = qzid;
                ques2.question_id = qsid;
                ques2.question_statement = q;
                if (f)
                {
                    ques2.correct_answer = text_f.ToLower();
                }
                else if (t)
                {
                    ques2.correct_answer = text_t.ToLower();
                }
                else
                {
                    ques2.correct_answer = text_t.ToLower();
                    //MessageBox.Show("Select Correct Answer");
                }
                ques2.answer = "false";
                ques2.category_id = 2;
                obj.Questions.Add(ques2);

                return obj.SaveChanges();
                
            }
        }

        public int AddBlanks(string x,string q,string c)
        {
            using (ExamModels obj = new ExamModels())
            {

                //var x = session.Instance.quiz.quiz_code;
                int qsid = obj.Questions.Select(a => a.question_id).Max() + 1;
                int qzid = obj.Quizs.Where(a => a.quiz_code == (x)).Select(a => a.quiz_id).First();

                Question ques1 = new Question();
                ques1.quiz_id = qzid;
                ques1.question_id = qsid;
                ques1.question_statement = q;
                ques1.correct_answer = c;
                ques1.category_id = 3;
                ques1.answer = "";
                obj.Questions.Add(ques1);

                return obj.SaveChanges();

            }
        }

        public Tuple<string, string, TimeSpan, int> AddQuiz(int teach_id,string name,string code,TimeSpan t)
        {
            using (ExamModels obj = new ExamModels())
            {
                //var teach_id = session.Instance.user.t_id;
                Quiz q = new Quiz()
                {
                    quiz_name = name,
                    quiz_code = code,
                    time = t,
                    teacher_id = teach_id,

                };

                //session.Instance.quiz = q;
                obj.Quizs.Add(q);
                obj.SaveChanges();

                // to return quiz, here returning its attributes to make session in program:
                Tuple<string,string,TimeSpan,int> quiz =
                new Tuple<string, string, TimeSpan, int>(q.quiz_name,q.quiz_code,(TimeSpan)q.time,(int)q.teacher_id);
                return quiz;
            }
        }

        public Tuple<string[], string[], TimeSpan[]> QuizList(int x)
        {
            ExamModels obj = new ExamModels();
            //var x = session.Instance.user.t_id;
            var k= obj.Quizs.Where(a => a.teacher_id == x).Select(a => new { a.quiz_name, a.quiz_code, a.time }).ToList();

            string[] name=new string[k.Count()];
            string[] code = new string[k.Count()]; ;
            TimeSpan[] time = new TimeSpan[k.Count()];
            int i2 = 0;

            foreach(var i in k)
            {
                name[i2]=i.quiz_name;
                code[i2]=i.quiz_code;
                time[i2]=(TimeSpan)i.time;
                i2++;
            }

            Tuple<string[], string[], TimeSpan[]> quiz = new Tuple<string[], string[], TimeSpan[]>(name, code, time);
            return quiz;
        }

    }
}
