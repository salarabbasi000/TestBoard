﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace ExamService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IService1
    {

        [OperationContract]
        string GetData(int value);

        [OperationContract]
        CompositeType GetDataUsingDataContract(CompositeType composite);

        //Student:
        [OperationContract]
        int StudentRegister(Student x);

        [OperationContract]
        int StudentLogin(Student x);

        [OperationContract]
        int TeacherRegister(Teacher x);

        [OperationContract]
        int TeacherLogin(Teacher x);

        [OperationContract]
        Tuple<string[], int[], int[], DateTime[]> GradeBook(string aq);

        [OperationContract]
        IEnumerable<string> GetCorrectAns(string quizid);
        [OperationContract]
        bool SaveResult(string aq, int id, int wrong, int obt);

        [OperationContract]
        Tuple<int[], int[], string[], int[], string[], string[], TimeSpan[]> StartQuiz(string aq, string usercode);



        //Teacher:

        [OperationContract]
        int TeacherSignUp(string name, string email, string pass, string cpass, bool male, bool female, string m, string f);

        [OperationContract]
        int TeacherLogin(string email, string pass);

        [OperationContract]
        int AddMCQs(string x, string q, string ans1, string ans2, string ans3, string ans4, string c);

        [OperationContract]
        int AddTrueFalse(string x, string q, bool t, bool f, string text_t, string text_f);

        [OperationContract]
        int AddBlanks(string x, string q, string c);

        [OperationContract]
        Tuple<string, string, TimeSpan, int> AddQuiz(int teach_id, string name, string code, TimeSpan t);

        [OperationContract]
        Tuple<string[], string[], TimeSpan[]> QuizList(int x);

    }


    // Use a data contract as illustrated in the sample below to add composite types to service operations.
    [DataContract]
    public class CompositeType
    {
        bool boolValue = true;
        string stringValue = "Hello ";

        [DataMember]
        public bool BoolValue
        {
            get { return boolValue; }
            set { boolValue = value; }
        }

        [DataMember]
        public string StringValue
        {
            get { return stringValue; }
            set { stringValue = value; }
        }
    }
}
